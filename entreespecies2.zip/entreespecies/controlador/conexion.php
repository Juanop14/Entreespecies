<?php
$conexion = new mysqli("localhost","root","","entre_especies"); 
$conexion->set_charset("utf8");
?>