SET NAMES 'utf8';SET FOREIGN_KEY_CHECKS=0;SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';SET AUTOCOMMIT=0;START TRANSACTION;SET time_zone = '+00:00';SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0;/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;DROP TABLE IF EXISTS `citainterna`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `citainterna` (
CREATE TABLE `citainterna` (
  `id_cita_int` int(3) NOT NULL,
  `id_mascota` int(3) DEFAULT NULL,
  `Documento` int(3) DEFAULT NULL,
  PRIMARY KEY (`id_cita_int`),
  UNIQUE KEY `id_mascota` (`id_mascota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `clientes`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `clientes` (
CREATE TABLE `clientes` (
  `idCliente` int(3) NOT NULL,
  `Documento_cliemte` int(15) DEFAULT NULL,
  `tipo_Doc` int(15) DEFAULT NULL,
  `NomCliente` varchar(20) DEFAULT NULL,
  `Apellido_cliente` varchar(20) DEFAULT NULL,
  `Direccion` varchar(20) DEFAULT NULL,
  `Telefono` int(15) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idCliente`),
  CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `mascotas` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `compras`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `compras` (
CREATE TABLE `compras` (
  `Id_compra` int(3) NOT NULL,
  `Id_proveedor` int(3) DEFAULT NULL,
  `Fecha_compra` date DEFAULT NULL,
  `Forma_pago` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id_compra`),
  KEY `Id_proveedor` (`Id_proveedor`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`Id_proveedor`) REFERENCES `proveedores` (`Id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `configuracion`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `configuracion` (
CREATE TABLE `configuracion` (
  `id_Configuracion` int(2) NOT NULL,
  `id_Rol` int(4) NOT NULL,
  `id_Permiso` int(3) NOT NULL,
  PRIMARY KEY (`id_Configuracion`),
  KEY `id_Permiso` (`id_Permiso`),
  KEY `id_Rol` (`id_Rol`),
  CONSTRAINT `configuracion_ibfk_1` FOREIGN KEY (`id_Rol`) REFERENCES `roles` (`id_Rol`),
  CONSTRAINT `configuracion_ibfk_2` FOREIGN KEY (`id_Permiso`) REFERENCES `permisos` (`id_Permiso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `detcompras`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `detcompras` (
CREATE TABLE `detcompras` (
  `Id_detallecompra` int(3) NOT NULL,
  `Id_compra` int(3) DEFAULT NULL,
  `Id_producto` int(3) DEFAULT NULL,
  `Cantidad` int(4) DEFAULT NULL,
  `Precio_compra` float DEFAULT NULL,
  `Subtotal` float DEFAULT NULL,
  PRIMARY KEY (`Id_detallecompra`),
  KEY `Id_compra` (`Id_compra`),
  KEY `Id_producto` (`Id_producto`),
  CONSTRAINT `detcompras_ibfk_1` FOREIGN KEY (`Id_compra`) REFERENCES `compras` (`Id_compra`),
  CONSTRAINT `detcompras_ibfk_2` FOREIGN KEY (`Id_producto`) REFERENCES `productos` (`Id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `detexterna`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `detexterna` (
CREATE TABLE `detexterna` (
  `Id_externa` int(3) NOT NULL,
  `Id_cita_int` int(3) DEFAULT NULL,
  `Nom_cita` varchar(35) DEFAULT NULL,
  `Fecha_hora_cita` datetime DEFAULT NULL,
  `Estado_cita` varchar(15) DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  PRIMARY KEY (`Id_externa`),
  KEY `Id_cita_int` (`Id_cita_int`),
  CONSTRAINT `detexterna_ibfk_1` FOREIGN KEY (`Id_cita_int`) REFERENCES `citaexterna` (`id_cita_int`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `detinterna`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `detinterna` (
CREATE TABLE `detinterna` (
  `Id_interna` int(3) NOT NULL,
  `Id_cita_int` int(3) DEFAULT NULL,
  `Nom_cita` varchar(35) DEFAULT NULL,
  `Fecha_hora_cita` datetime DEFAULT NULL,
  `Estado_cita` varchar(15) DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  PRIMARY KEY (`Id_interna`),
  KEY `Id_cita_int` (`Id_cita_int`),
  CONSTRAINT `detinterna_ibfk_1` FOREIGN KEY (`Id_cita_int`) REFERENCES `citainterna` (`id_cita_int`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `detventas`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `detventas` (
CREATE TABLE `detventas` (
  `Id_detalle_venta` int(3) NOT NULL,
  `Id_venta` int(3) DEFAULT NULL,
  `Id_servicio` int(3) DEFAULT NULL,
  `Id_producto` int(3) DEFAULT NULL,
  `Cantidad` int(5) DEFAULT NULL,
  `Subtotal_producto` float DEFAULT NULL,
  `Subtotal_servicio` float DEFAULT NULL,
  PRIMARY KEY (`Id_detalle_venta`),
  KEY `Id_venta` (`Id_venta`),
  KEY `Id_servicio` (`Id_servicio`),
  KEY `Id_producto` (`Id_producto`),
  CONSTRAINT `detventas_ibfk_1` FOREIGN KEY (`Id_venta`) REFERENCES `ventas` (`Id_venta`),
  CONSTRAINT `detventas_ibfk_2` FOREIGN KEY (`Id_servicio`) REFERENCES `servicios` (`Id_servicio`),
  CONSTRAINT `detventas_ibfk_3` FOREIGN KEY (`Id_producto`) REFERENCES `productos` (`Id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `mascotas`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `mascotas` (
CREATE TABLE `mascotas` (
  `id_mascota` int(3) NOT NULL AUTO_INCREMENT,
  `idcliente` int(3) NOT NULL,
  `Nombre_mascota` varchar(20) NOT NULL,
  `foto` blob NOT NULL,
  `fecha_nacimineto` date NOT NULL,
  `Color_mascota` varchar(12) NOT NULL,
  `Especie` varchar(12) NOT NULL,
  `Raza` varchar(20) NOT NULL,
  `genero` varchar(15) NOT NULL,
  `Info_mascota` varchar(200) NOT NULL,
  PRIMARY KEY (`id_mascota`),
  UNIQUE KEY `idcliente` (`idcliente`),
  CONSTRAINT `mascotas_ibfk_1` FOREIGN KEY (`id_mascota`) REFERENCES `citaexterna` (`id_mascota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `permisos`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `permisos` (
CREATE TABLE `permisos` (
  `id_Permiso` int(3) NOT NULL AUTO_INCREMENT,
  `nombre_Permiso` varchar(30) NOT NULL,
  PRIMARY KEY (`id_Permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `productos`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `productos` (
CREATE TABLE `productos` (
  `Id_producto` int(3) NOT NULL,
  `Id_proveedor` int(3) DEFAULT NULL,
  `Id_categoria` int(3) DEFAULT NULL,
  `foto` blob DEFAULT NULL,
  `Nom_producto` varchar(20) DEFAULT NULL,
  `Disponibilidad` char(15) DEFAULT NULL,
  `Cantidad` int(4) DEFAULT NULL,
  `Fecha_vencimiento` date DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  PRIMARY KEY (`Id_producto`),
  KEY `Id_proveedor` (`Id_proveedor`),
  KEY `Id_categoria` (`Id_categoria`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`Id_proveedor`) REFERENCES `proveedores` (`Id_proveedor`),
  CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`Id_categoria`) REFERENCES `categorias` (`Id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `proveedores`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `proveedores` (
CREATE TABLE `proveedores` (
  `Id_proveedor` int(3) NOT NULL,
  `Nit_proveedor` int(3) DEFAULT NULL,
  `Nom_provedor` varchar(35) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Telefono` int(12) DEFAULT NULL,
  `Direccion` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`Id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `roles`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `roles` (
CREATE TABLE `roles` (
  `id_Rol` int(1) NOT NULL AUTO_INCREMENT,
  `nombre_Rol` varchar(15) NOT NULL,
  PRIMARY KEY (`id_Rol`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `roles` VALUES ('1','administrador');
INSERT INTO `roles` VALUES ('2','empleado');
;DROP TABLE IF EXISTS `servicios`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `servicios` (
CREATE TABLE `servicios` (
  `Id_servicio` int(3) NOT NULL,
  `Nom_servicio` varchar(35) DEFAULT NULL,
  `Categoria` varchar(35) DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  PRIMARY KEY (`Id_servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `usuario`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `usuario` (
CREATE TABLE `usuario` (
  `id_Usuario` int(4) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(30) NOT NULL,
  `apellido_usuario` varchar(30) NOT NULL,
  `contraseña` varchar(12) NOT NULL,
  `id_Rol` int(3) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `estado` char(10) NOT NULL,
  `documento` int(15) NOT NULL,
  `telefono` bigint(20) NOT NULL,
  PRIMARY KEY (`id_Usuario`),
  KEY `correo` (`correo`),
  KEY `correo_2` (`correo`),
  KEY `id_Rol` (`id_Rol`),
  KEY `correo_3` (`correo`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_Rol`) REFERENCES `roles` (`id_Rol`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;DROP TABLE IF EXISTS `ventas`;/*!40101 SET @saved_cs_client     = @@character_set_client */;/*!40101 SET character_set_client = utf8 */;CREATE TABLE `ventas` (
CREATE TABLE `ventas` (
  `Id_venta` int(3) NOT NULL,
  `Id_servicio` int(3) DEFAULT NULL,
  `idCliente` int(3) DEFAULT NULL,
  `Fecha_venta` date DEFAULT NULL,
  `Forma_pago` varchar(50) DEFAULT NULL,
  `Totventas_pro_ser` float DEFAULT NULL,
  PRIMARY KEY (`Id_venta`),
  KEY `Id_servicio` (`Id_servicio`),
  KEY `idCliente` (`idCliente`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`Id_servicio`) REFERENCES `servicios` (`Id_servicio`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`idCliente`) REFERENCES `clientes` (`idCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

;/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;COMMIT;