<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Document</title>
</head>
<body>
    <form action="">
        <h1>Inicio De Sesion</h1><br>
        <center>
            <label for="" class="lab">
                <i class="fa-solid fa-user"></i>
                <input type="text" id="correo">
            </label>
        </center><br>
        <center>
            <label for="" class="lab">
                <i class="fa-solid fa-lock"></i>
                <input type="text" id="contraseña">
            </label> 
        </center><br>
        <center>
            <button class="but">Ingresar</button>
        </center> <br>
        <a href="" class="link">Olvide Mi Contraseña</a>
        <br>
    </form>
</body>
</html>