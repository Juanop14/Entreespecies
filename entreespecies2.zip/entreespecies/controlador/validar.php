
<?php
/*session_star();
if(isset($_SESSION['id_Usuario'])) {
    header("Location: ../vista/admin.php");
}*/
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['correo'])) {
        $correo = $_POST['correo'];
    } else {
        $correo = '';
    }

    if (isset($_POST['contraseña'])) {
        $contraseña = $_POST['contraseña'];
    } else {
        $contraseña = '';
    }

    $_SESSION['correo'] = $correo;

    $conexion = mysqli_connect("localhost", "root", "", "entre_especies");

    $consulta = "SELECT * FROM usuario WHERE correo='$correo' AND contraseña='$contraseña'";
    $resultado = mysqli_query($conexion, $consulta);

    if (mysqli_num_rows($resultado) > 0) {
        $filas = mysqli_fetch_array($resultado);
        if ($filas['id_Rol'] == 1) {
            //le cambie a location 
            header("location: ../vista/html/indAdministrador.php");
        } else if ($filas['id_Rol'] == 2) {
            header("location: ../vista/html/indEmpleado.php");
        }
    } else {
        include ("error.php");
        ?>
        
        <?php
    }

    mysqli_free_result($resultado);
    mysqli_close($conexion);
}


/*

<?php
/*session_start(); codigo segundo corregido solo que me ejecuta el else sin igreasr ningun uusario

if (isset($_POST['correo'])) {
    $correo = $_POST['correo'];
} else {
    $correo = '';
}

if (isset($_POST['contraseña'])) {
    $contraseña = $_POST['contraseña'];
} else {
    $contraseña = '';
}

$_SESSION['correo'] = $correo;

$conexion = mysqli_connect("localhost", "root", "", "entre_especies");

$consulta = "SELECT * FROM usuario WHERE correo='$correo' AND contraseña='$contraseña'";
$resultado = mysqli_query($conexion, $consulta);

if (mysqli_num_rows($resultado) > 0) {
    $filas = mysqli_fetch_array($resultado);
    if ($filas['id_Rol'] == 1) {
        header("location:admin.php");
    } else if ($filas['id_Rol'] == 2) {
        header("location:empleados.php");
    }
} else {
    include ("error.php");
    ?>
    <h1 class="###">Error</h1>
    <?php
}

mysqli_free_result($resultado);
mysqli_close($conexion);*/




/* codigo original
<?php
$correo=$_POST['correo'];
$contraseña=$_POST['contraseña'];
session_start();
$_SESSION['correo']=$correo;

$conexion=mysqli_connect("localhost","root","","entre_especies");

$consulta="SELECT * FROM usuario where correo='$correo' and contraseña='$contraseña'";
$resultado=mysqli_query($conexion,$consulta);


$filas = mysqli_fetch_array($resultado);

if (mysqli_num_rows($resultado) > 0) {
    if($filas['id_Rol'] == 1){
        header("location:admin.php");
    }else if($filas['id_Rol'] == 2){
        header("location:empleados.php");
    }
}else {
    include ("error.php");
    ?>
    <h1 class="###">Error</h1>
    <?php
}



mysqli_free_result($resultado);
mysqli_close($conexion);*/